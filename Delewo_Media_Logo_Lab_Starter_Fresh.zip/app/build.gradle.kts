plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.delewo.medialab"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.delewo.medialab"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
