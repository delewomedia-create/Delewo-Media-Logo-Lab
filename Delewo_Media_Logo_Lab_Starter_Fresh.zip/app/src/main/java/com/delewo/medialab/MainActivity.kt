package com.delewo.medialab

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Delewo Media Logo Lab"
            textSize = 26f
        }
        val intro = TextView(this).apply {
            text = "Photo, video, logo and social media tools — starter version."
            textSize = 16f
            setPadding(0, 20, 0, 24)
        }
        val photo = Button(this).apply {
            text = "Choose Photo"
            setOnClickListener { pick("image/*", 100) }
        }
        val video = Button(this).apply {
            text = "Choose Video"
            setOnClickListener { pick("video/*", 101) }
        }
        val audio = Button(this).apply {
            text = "Choose Audio"
            setOnClickListener { pick("audio/*", 102) }
        }
        val share = Button(this).apply {
            text = "Share"
            setOnClickListener {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Created with Delewo Media Logo Lab")
                }
                startActivity(Intent.createChooser(send, "Share with"))
            }
        }
        layout.addView(title); layout.addView(intro)
        layout.addView(photo); layout.addView(video); layout.addView(audio); layout.addView(share)
        setContentView(layout)
    }

    private fun pick(type: String, code: Int) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { this.type = type }
        startActivityForResult(Intent.createChooser(intent, "Select file"), code)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data?.data != null) {
            Toast.makeText(this, "File selected: ${data.data}", Toast.LENGTH_LONG).show()
        }
    }
}
